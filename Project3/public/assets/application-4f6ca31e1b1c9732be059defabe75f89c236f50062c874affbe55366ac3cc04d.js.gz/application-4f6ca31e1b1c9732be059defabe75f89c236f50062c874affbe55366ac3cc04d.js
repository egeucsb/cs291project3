// app/javascript/application.js
import { Turbo } from "@hotwired/turbo-rails"
import "./controllers"
import "@hotwired/turbo-rails";
